package com.iot.heatingsystem.api;


import com.iot.heatingsystem.configuration.DeviceConfiguration;
import com.iot.heatingsystem.model.Device;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/info")
public class InfoController {

    @Autowired
    private DeviceConfiguration device;

    @GetMapping("/temperature")
    public ResponseEntity<Device> info(){
        return ResponseEntity.ok(device.getDevice());
    }

    @PostMapping("shutdown")
    public ResponseEntity<String> shutdown() {
        device.shutdown();
        return ResponseEntity.ok("Device is shutting down");
    }

    @GetMapping("/rand")
    public ResponseEntity<Device> temperature() {
        double max_temp = 26;
        double min_temp = 19;
        double x = min_temp + (Math.random() * ((max_temp - min_temp) + 1));
        device.setTemperature(x);
        return ResponseEntity.ok(device.getDevice());
    }


}
