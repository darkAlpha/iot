// Distributed with a free-will license.
// Use it any way you want, profit or free, provided it fits in the licenses of its associated works.
// This code is designed to work with the temperature


package com.iot.heatingsystem.configuration;


import com.iot.heatingsystem.model.Device;
import com.pi4j.Pi4J;
import com.pi4j.context.Context;
import com.pi4j.io.i2c.I2C;
import com.pi4j.io.i2c.I2CConfig;
import com.pi4j.util.Console;
import com.sun.istack.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;


/**
 * @author mura
 *
 * @apiNote
 *
 * @version 1.0.0
 *
 * DeviceConfiguration is main class of initializing of Device System properties
 *
 *
 */
@Component
public class DeviceConfiguration {

    Logger logger = LoggerFactory.getLogger(DeviceConfiguration.class);

    private static final int I2C_BUS = 1;
    private static final int I2C_DEVICE = 0x04;

    private static I2CConfig config;

    Device device;

    @Value("${device.id}")
    private String deviceId;

    @Value("${device.name}")
    private String deviceName;

    @PostConstruct
    public void init() {

        long startTime = System.currentTimeMillis();

        logger.info("Starting initializing Device...");

        try {

            System.setProperty("pi4j.host", "rpi3bp.savage.lan");

            var console = new Console();

            console.title("The Pi4J Project", "Initializing device");

            var pi4J = Pi4J.newAutoContext();

            device = createDevice(deviceId, deviceName);


            config
                    = I2C.newConfigBuilder((Context) pi4J)
                    .id(device.getId())
                    .name(device.getName())
                    .bus(I2C_BUS)
                    .device(I2C_DEVICE)
                    .build();

            infoTemperature();

            device.setTemperature(computeTemperature());

        } catch (Exception e){
            logger.debug("Exception {}", e.getStackTrace());
            System.out.println("Exception: " + e.getStackTrace());
        }

        logger.info(" Finished DeviceConfiguration in {} ms" , System.currentTimeMillis() - startTime);

    }



    @PreDestroy
    public void shutdown() {

    }

    public String getName() {
        return config.getName();
    }

    public Device getDevice() {
        return device;
    }


    private Device createDevice(  String id, String name) throws NullPointerException{

        Device device = new Device();
        device.setId(id);
        device.setName(name);

        return device;
    }

    private void infoTemperature() throws Exception{

        byte[] data = new byte[2];
//        dev.read(0x00, data, 0, 2);

        // Convert the data to 12-bits
        int temp = ((data[0] & 0xFF) * 256 + (data[1] & 0xF0)) / 16;
        if (temp > 2047) {
            temp -= 4096;
        }

        //European metric
        double cTemp = temp * 0.0625;

        // American metric
        double fTemp = cTemp * 1.8 + 32;


    }

    public double computeTemperature() throws Exception{
        byte[] data = new byte[2];
//        dev.read(0x00, data, 0, 2);

        // Convert the data to 12-bits
        int temp = ((data[0] & 0xFF) * 256 + (data[1] & 0xF0)) / 16;
        if (temp > 2047) {
            temp -= 4096;
        }

        //European metric
        double cTemp = temp * 0.0625;
        // American metric
        double fTemp = cTemp * 1.8 + 32;
        double max_temp = 33;
        double min_temp = 17;
        double x = min_temp + (Math.random() * ((max_temp - min_temp) + 1));
        cTemp = x;
        return cTemp;

    }

    public void setTemperature(double newTemperature){
        device.setTemperature(newTemperature);
    }

}
