package com.iot.heatingsystem.service;

import com.iot.heatingsystem.model.Device;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;

public class SenderServiceImpl implements SenderService {

    Logger logger = LoggerFactory.getLogger(SenderServiceImpl.class);

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    private Device device;

    @Value("${kafka-topic}")
    private String topicName;

    @Override
    public void send(String msg) {

        try {

            long startTime = System.currentTimeMillis();
            logger.info("Sending message...");

            String action = device.toString();

            kafkaTemplate.send(topicName, action);

            logger.info(" Finished sending message by Kafka {}", System.currentTimeMillis() - startTime);

        }catch (Exception e) {
            logger.info("Exception : " + e.getStackTrace());
        }

    }
}
