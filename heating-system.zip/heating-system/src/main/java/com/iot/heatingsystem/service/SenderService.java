package com.iot.heatingsystem.service;

public interface SenderService {

    void send(String msg);
}
