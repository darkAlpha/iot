package com.iot.heatingsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HeatingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
